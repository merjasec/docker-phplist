<?php


Redirect('home');
